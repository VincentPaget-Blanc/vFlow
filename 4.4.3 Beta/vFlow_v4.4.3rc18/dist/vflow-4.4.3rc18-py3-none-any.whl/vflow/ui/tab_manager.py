"""Notebook/tab lifecycle implementation for vFlow.

``FlowTabManagerBase`` is the first physically extracted major UI class in the
v4.2 refactor.  It deliberately resolves ``FlowApp`` only when a manager is
constructed, preserving the lightweight/lazy import behavior of the public
``FlowTabManager`` proxy symbol.
"""

from __future__ import annotations

from vflow.ui.fonts import semantic_font


class FlowTabManagerBase:
    """Own a ttk.Notebook containing independent FlowApp instances."""

    flow_app_class = None
    app_version = None

    def _flow_app_type(self):
        cls = self.flow_app_class
        if cls is not None:
            return cls
        from vflow.ui.app import FlowApp
        return FlowApp

    def __init__(self, root):
        import tkinter as tk
        from tkinter import ttk

        from vflow import __version__
        from vflow.config.styles import _apply_ttk_style
        from vflow.config.themes import THEMES

        self.root = root
        root.title(f"vFlow {self.app_version or __version__}")
        root.geometry("1500x960")

        self._theme_name = 'dark'
        self.T = THEMES['dark']
        T = self.T
        _apply_ttk_style(T)
        root.configure(bg=T['sidebar_bg'])

        self.notebook = ttk.Notebook(root)
        self.notebook.pack(fill=tk.BOTH, expand=True)

        self._apps: list = []
        self._new_tab(title=' Main ', parent_label=None,
                      filtered_data=None, default_x=None, default_y=None)
        self.notebook.bind('<Button-3>', self._on_tab_rclick)
        import sys
        if sys.platform == 'darwin':
            self.notebook.bind('<Control-Button-1>', self._on_tab_rclick)
        self.notebook.bind('<<NotebookTabChanged>>', self._on_tab_selected)

    def _on_tab_selected(self, event=None):
        if not self._apps: return
        selected = self.notebook.select()
        if not selected: return
        index = self.notebook.index(selected)
        if index < len(self._apps): self._apps[index].refresh_plot()

    def _new_tab(self, title, parent_label, filtered_data,
                 default_x, default_y,
                 parent_gate=None, parent_region=None, population_lineage=None,
                 excluded_files=None, axis_aliases=None):
        import tkinter as tk
        from tkinter import ttk

        frame = ttk.Frame(self.notebook, style='TFrame')
        self.notebook.add(frame, text=title)

        if parent_label is not None:
            T = self.T
            from vflow.ui.fonts import semantic_fonts
            hdr = tk.Frame(frame, bg=T['header_bg'], height=semantic_fonts(self.root)['VFlowBody'].metrics('linespace')+12)
            hdr._vflow_tab_header = True
            hdr.pack(fill=tk.X, side=tk.TOP)
            hdr.pack_propagate(False)

            def _close_this():
                idx = self.notebook.index(frame)
                self._close_tab(idx)

            tk.Label(hdr, text=f'  ↳ {parent_label}',
                     bg=T['header_bg'], fg=T['fg'],
                     font=semantic_font(self.root)).pack(side=tk.LEFT, padx=4)
            close_btn = tk.Button(
                hdr, text=' ✕ ', command=_close_this,
                bg=T['header_bg'], fg=T['fg_dim'],
                activebackground='#c33', activeforeground='white',
                relief='flat', font=semantic_font(self.root), bd=0, padx=4)
            close_btn.pack(side=tk.RIGHT, padx=4)
            inner = ttk.Frame(frame, style='TFrame')
            inner.pack(fill=tk.BOTH, expand=True)
        else:
            inner = frame

        app = self._flow_app_type()(
            self.root, container=inner,
            parent_label=parent_label, manager=self)
        if filtered_data:
            self._load_filtered(
                app, filtered_data, default_x, default_y,
                parent_gate=parent_gate,
                parent_region=parent_region,
                population_lineage=population_lineage,
                excluded_files=excluded_files or {},
                axis_aliases=axis_aliases or {})
        if hasattr(app, '_workspace') and parent_label is not None:
            app._workspace.tab_state(app)
            app._workspace.mark_dirty()
        self._apps.append(app)
        self.notebook.select(frame)
        return app

    @staticmethod
    def _load_filtered(app, filtered_data, default_x, default_y,
                       parent_gate=None, parent_region=None, population_lineage=None,
                       excluded_files=None, axis_aliases=None):
        """Pre-load one child population with frozen v4.1.11 tab semantics."""
        import tkinter as tk

        from vflow.config.constants import FILE_COLORS, _N_FILE_COLORS
        from vflow.core.gate_definition import GateDefinition

        # The tab boundary stores immutable analysis provenance.  Be defensive
        # if a caller supplies a live UI gate: Tk Variables cannot be deep-
        # copied/pickled and must never leak into AnalysisState.  The normal
        # double-click path already supplies a plain snapshot; this hardens the
        # public manager boundary against alternate/internal callers.
        plain_parent_gate = parent_gate
        if parent_gate is not None:
            plain_parent_gate = GateDefinition.from_live_dict(
                parent_gate, variable_types=(tk.Variable,)
            ).to_plain_dict()

        app._analysis_state_obj().set_population_context(
            parent_gate=plain_parent_gate,
            parent_region=parent_region,
            population_lineage=population_lineage,
        )

        # Child tabs inherit the exact session-scoped nomenclature map so raw
        # Batch Stats rereads use the same labels as their parent analysis.
        app.axis_aliases = dict(axis_aliases or {})

        if excluded_files:
            app._dataset_state_obj().inherit_excluded_files(excluded_files)
            app._rebuild_excluded_list()

        for path, df in filtered_data.items():
            if path in app.loaded_files:
                continue
            cidx = len(app.loaded_files)
            app.file_colors[path] = FILE_COLORS[cidx % _N_FILE_COLORS]
            try:
                # Scientific/behavioral invariant: UI registration succeeds
                # before the DataFrame becomes visible in loaded_files.
                app._add_file_row(path)
            except Exception:
                app.file_colors.pop(path, None)
                app.file_vars.pop(path, None)
                raise
            app.loaded_files[path] = df
            app._data_generation += 1

        if not app.loaded_files:
            return
        sample = next(iter(app.loaded_files.values()))
        cols = list(sample.columns)
        app.x_menu['values'] = cols
        app.y_menu['values'] = cols

        if default_x and default_x in cols:
            app.x_var.set(default_x); app.x_channel = default_x
        elif cols:
            app.x_var.set(cols[0]); app.x_channel = cols[0]

        if default_y and default_y in cols:
            app.y_var.set(default_y); app.y_channel = default_y
        elif len(cols) > 1:
            app.y_var.set(cols[1]); app.y_channel = cols[1]

        if not app.lock_scale_var.get():
            app.fit_axes_var.set(True)

        app.refresh_plot()

    def open_subgate_tab(self, label: str, filtered_data: dict,
                         parent_x: str, parent_y: str, total_cells: int,
                         parent_gate: dict = None, parent_region: str = None,
                         population_lineage: list = None,
                         excluded_files: dict = None,
                         axis_aliases: dict = None):
        """Called by a FlowApp when the user double-clicks a gated region."""
        short = label[:22]
        tab_title = f' ↳ {short}  ({total_cells:,}) '
        self._new_tab(
            title=tab_title, parent_label=label,
            filtered_data=filtered_data,
            default_x=parent_x, default_y=parent_y,
            parent_gate=parent_gate, parent_region=parent_region,
            population_lineage=population_lineage or [],
            excluded_files=excluded_files or {},
            axis_aliases=axis_aliases or {})

    def _on_tab_rclick(self, event):
        import tkinter as tk

        try:
            idx = self.notebook.index(f'@{event.x},{event.y}')
        except tk.TclError:
            return
        if idx == 0:
            return 'break'
        previous = getattr(self, '_tab_context_menu', None)
        if previous is not None: previous.destroy()
        menu = tk.Menu(self.root, tearoff=0)
        self._tab_context_menu = menu
        menu.add_command(
            label='✕  Close tab', command=lambda i=idx: self._close_tab(i))
        try: menu.tk_popup(event.x_root, event.y_root)
        finally: menu.grab_release()
        return 'break'

    def _close_tab(self, idx: int):
        """Close sub-gate tab by notebook index and cancel pending callbacks."""
        tabs = self.notebook.tabs()
        if idx <= 0 or idx >= len(tabs):
            return
        if 0 < idx < len(self._apps):
            sub_app = self._apps[idx]
            if hasattr(sub_app, '_dispose_sidebar'): sub_app._dispose_sidebar()
            for attr in ('_refresh_pending', '_replot_pending',
                         '_sens_rerun_pending'):
                pending = getattr(sub_app, attr, None)
                if pending:
                    try:
                        sub_app.root.after_cancel(pending)
                    except Exception:
                        pass
                    setattr(sub_app, attr, None)
            if hasattr(sub_app, '_workspace'):
                binding=getattr(sub_app,'_workspace_resize_binding',None)
                if binding: sub_app.root.unbind('<Configure>',binding)
                owner = sub_app._workspace; key = sub_app._workspace_tab_id
                owner.apps.pop(key, None); owner.stores.pop(key, None)
                owner.document.tabs.pop(key, None)
                if not owner.restoring: owner.mark_dirty()
            self._apps.pop(idx)
        tab_id = tabs[idx]
        try:
            tab_widget = self.notebook.nametowidget(tab_id)
        except (AttributeError, KeyError):
            tab_widget = None
        self.notebook.forget(tab_id)
        # ttk.Notebook.forget() only unmaps the child; it does not destroy it.
        # Destroy explicitly so closed FlowApp canvases/widgets and callback
        # references cannot accumulate over repeated sub-gate exploration.
        if tab_widget is not None:
            try:
                if tab_widget.winfo_exists():
                    tab_widget.destroy()
            except (AttributeError, TypeError):
                pass


def __getattr__(name: str):
    # Preserve the existing public lazy-proxy contract.  The legacy module now
    # defines FlowTabManager as a thin subclass of FlowTabManagerBase.
    if name == "FlowTabManager":
        from vflow.legacy.vflow_legacy import FlowTabManager
        return FlowTabManager
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = ["FlowTabManager", "FlowTabManagerBase"]
